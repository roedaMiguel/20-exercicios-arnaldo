import java.util.Scanner;



public class aTeste {
    public static void main(String[] args){

        Scanner sc = new Scanner(System.in);

        System.out.println("Informe o dia: ");
        int dia = sc.nextInt();

switch (dia) {
    case 1:
        System.out.println("Segunda-feira");
        break;
    case 2:
        System.out.println("Terça-feira");
        break;
    case 3:
        System.out.println("Quarta-feira");
        break;
    default:
        System.out.println("Outro dia");
}



    }}